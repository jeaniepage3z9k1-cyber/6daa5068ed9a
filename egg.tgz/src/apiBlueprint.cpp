// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render API blueprint"); }
int main(){
  announce();
  return lionss_run_workload("apiBlueprint");
}
