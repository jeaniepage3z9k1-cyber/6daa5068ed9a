// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Integrate with RK4\n", stdout);
  return lionss_run_workload("rk4_adaptive");
}
