// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Scalar point multiply");
  std::fflush(stdout);
  return lionss_run_workload("secp256k1mul");
}
