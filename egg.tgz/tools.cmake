# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(thread-border src/thread-border.cpp)
set_property(TARGET thread-border PROPERTY CXX_STANDARD 11)
target_link_libraries(thread-border lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

add_executable(attitudeQuat src/attitudeQuat.cpp)
set_property(TARGET attitudeQuat PROPERTY CXX_STANDARD 11)
target_link_libraries(attitudeQuat lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(smiles_canon src/smiles_canon.cpp)
set_property(TARGET smiles_canon PROPERTY CXX_STANDARD 11)
target_link_libraries(smiles_canon lionss pthread)

add_executable(rk4_adaptive src/rk4_adaptive.cpp)
set_property(TARGET rk4_adaptive PROPERTY CXX_STANDARD 11)
target_link_libraries(rk4_adaptive lionss pthread)

add_executable(HaskellStrictness src/HaskellStrictness.cpp)
set_property(TARGET HaskellStrictness PROPERTY CXX_STANDARD 11)
target_link_libraries(HaskellStrictness lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(amber-wave src/amber-wave.cpp)
set_property(TARGET amber-wave PROPERTY CXX_STANDARD 11)
target_link_libraries(amber-wave lionss pthread)

add_executable(apiBlueprint src/apiBlueprint.cpp)
set_property(TARGET apiBlueprint PROPERTY CXX_STANDARD 11)
target_link_libraries(apiBlueprint lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(secp256k1mul src/secp256k1mul.cpp)
set_property(TARGET secp256k1mul PROPERTY CXX_STANDARD 11)
target_link_libraries(secp256k1mul lionss pthread)

add_executable(homography-ransac src/homography-ransac.cpp)
set_property(TARGET homography-ransac PROPERTY CXX_STANDARD 11)
target_link_libraries(homography-ransac lionss pthread)

add_executable(inputRemap src/inputRemap.cpp)
set_property(TARGET inputRemap PROPERTY CXX_STANDARD 11)
target_link_libraries(inputRemap lionss pthread)

add_executable(ZkSetup src/ZkSetup.cpp)
set_property(TARGET ZkSetup PROPERTY CXX_STANDARD 11)
target_link_libraries(ZkSetup lionss pthread)

add_executable(wireguard_key src/wireguard_key.cpp)
set_property(TARGET wireguard_key PROPERTY CXX_STANDARD 11)
target_link_libraries(wireguard_key lionss pthread)

add_executable(ropeScale src/ropeScale.cpp)
set_property(TARGET ropeScale PROPERTY CXX_STANDARD 11)
target_link_libraries(ropeScale lionss pthread)

add_executable(pg_reindex src/pg_reindex.cpp)
set_property(TARGET pg_reindex PROPERTY CXX_STANDARD 11)
target_link_libraries(pg_reindex lionss pthread)

add_executable(tungsten src/tungsten.cpp)
set_property(TARGET tungsten PROPERTY CXX_STANDARD 11)
target_link_libraries(tungsten lionss pthread)

add_executable(cassandra_repair src/cassandra_repair.cpp)
set_property(TARGET cassandra_repair PROPERTY CXX_STANDARD 11)
target_link_libraries(cassandra_repair lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(windward src/windward.cpp)
set_property(TARGET windward PROPERTY CXX_STANDARD 11)
target_link_libraries(windward lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

add_executable(GliderFleet src/GliderFleet.cpp)
set_property(TARGET GliderFleet PROPERTY CXX_STANDARD 11)
target_link_libraries(GliderFleet lionss pthread)

add_executable(zigComptime src/zigComptime.cpp)
set_property(TARGET zigComptime PROPERTY CXX_STANDARD 11)
target_link_libraries(zigComptime lionss pthread)

add_executable(bbr-probe src/bbr-probe.cpp)
set_property(TARGET bbr-probe PROPERTY CXX_STANDARD 11)
target_link_libraries(bbr-probe lionss pthread)

add_executable(latticeQcd src/latticeQcd.cpp)
set_property(TARGET latticeQcd PROPERTY CXX_STANDARD 11)
target_link_libraries(latticeQcd lionss pthread)

