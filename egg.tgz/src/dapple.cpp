// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scatter dapple light\n", stdout);
  return lionss_run_workload("dapple");
}
