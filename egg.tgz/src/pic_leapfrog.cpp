// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Advance leapfrog step"); }
int main(){
  announce();
  return lionss_run_workload("pic_leapfrog");
}
